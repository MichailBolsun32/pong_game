import arcade

SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SCREEN_TITLE = "Pong Game"

class Racket(arcade.Sprite):
    def __init__(self):
        super().__init__('racket.png', 0.025)
        self.center_x = SCREEN_WIDTH / 2
        self.center_y = SCREEN_HEIGHT / 5

    def update(self):
        self.center_x += self.change_x
        if self.right >= SCREEN_WIDTH:
            self.right = SCREEN_WIDTH
        if self.left <= 0:
            self.left = 0

class Ball(arcade.Sprite):
    def __init__(self):
        super().__init__('ball.png', 0.02)
        self.center_x = SCREEN_WIDTH / 2
        self.center_y = SCREEN_HEIGHT / 2
        self.change_x = 2
        self.change_y = 2

    def update(self):
        self.center_x += self.change_x
        self.center_y += self.change_y
        if self.right >= SCREEN_WIDTH:
            self.change_x = -self.change_x
        if self.left <= 0:
            self.change_x = -self.change_x
        if self.top >= SCREEN_HEIGHT:
            self.change_y = - self.change_y
        if self.bottom <= 0:
            self.change_y = - self.change_y

class Game(arcade.Window):
    def __init__(self):
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
        self.glasses = 0
        self.racket = Racket()
        self.ball = Ball()

    def on_draw(self): #отрисовываем по умолчанию 60 раз в сек
        self.clear((255, 255, 255))
        self.racket.draw()
        self.ball.draw()
        arcade.draw_text(f"Счет: {self.glasses}",
                         start_x = SCREEN_WIDTH / 2, start_y=50,
                         color=arcade.color.BLACK,
                         font_size=24,
                         anchor_x="center")

    def update(self, delta):
        if arcade.check_for_collision(self.racket, self.ball):
            # изменение направлкния мяча
            self.ball.change_y = -self.ball.change_y
            # Дополнительно: корректировка положения мяча, чтобы избежать застревания
            if self.ball.center_y < self.racket.top:
                self.ball.center_y = self.racket.top + self.ball.top
            # изменение счета
            self.glasses += 1

        self.ball.update()
        self.racket.update()

    def on_key_press(self, key, modifiers):
        if key == arcade.key.RIGHT:
            self.racket.change_x = 3
        if key == arcade.key.LEFT:
            self.racket.change_x = -3


if __name__ == '__main__':
    window = Game()
    arcade.run()